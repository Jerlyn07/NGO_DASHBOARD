
# Import Necessary Libraries related to HTML tags and various core components like slider, checboxes, dropdowns etc.
import dash
import dash_html_components as html
import dash_core_components as dcc
import plotly.graph_objs as go
import pandas as pd
import plotly.express as px

#Start the dash application
app = dash.Dash(__name__,assets_external_path='typography.css')



colors = {
    'background': '#111111',
    'text': 'white',
    'subtext': '#7FDBFF'
    
}

cafe_colors =  ['rgb(146, 123, 21)', 'rgb(177, 180, 34)', 'rgb(206, 206, 40)',
                'rgb(175, 51, 21)', 'rgb(35, 36, 21)']

df = pd.DataFrame({
    "Year": ["2016", "2017", "2018","2019","2020","2016", "2017", "2018","2019","2020"],
    "Population": [150, 250, 200, 180, 210, 280, 400, 220,510, 430],
    "Gender": ["Female", "Female", "Female", "Female", "Female", "Male", "Male", "Male", "Male", "Male"]
})

fig = px.line(df, x="Year", y="Population", color="Gender", title="Attrition distribution by gender of children in NGOs")

fig.update_layout(
    plot_bgcolor=colors['background'],
    paper_bgcolor=colors['background'],
    font_color=colors['text']
)

df1 = pd.DataFrame({
    "Branch": ["VB Community", "St.Pathrick's trust", "Jonathan's foundation","Dalit's Foundation","The Christian trust", "VB Community", "St.Pathrick's trust", "Jonathan's foundation","Dalit's Foundation","The Christian trust",],
    "Count": [150, 250, 200, 180, 210, 280, 400, 220,510, 430],
    "City": ["Volunteers", "Volunteers", "Volunteers", "Volunteers", "Volunteers", "Benefitiaries", "Benefitiaries", "Benefitiaries", "Benefitiaries", "Benefitiaries"]
})

fig1 = px.bar(df1, x="Branch", y="Count", color="City", barmode="group")

fig1.update_layout(
    plot_bgcolor=colors['background'],
    paper_bgcolor=colors['background'],
    font_color=colors['text']
)
fig2=go.Figure()

fig2.update_layout(
    plot_bgcolor=colors['background'],
    paper_bgcolor=colors['background'],
    font_color=colors['text']
)

#HTML layout and Graph components are defined in this section
app.layout = html.Div(style={'backgroundColor': colors['background']},children=[html.H2(children='NGO MANAGEMENT DASHBOARD',style={
            'textAlign': 'center',
            'color': '#7FDBFF'
        }),
      html.Div(children='DONATIONS AND HUMAN POWER MANAGEMENT', style={
        'textAlign': 'center',
        'color': '#7FDBFF'
    }),
                                
  #-----------------------
                                html.Div(
            [
                html.Div(
                    [
                        html.P('Choose the medium of donations[Select the checkboxes]',style={'color':'red'}),
                        dcc.Checklist(
                                id = 'Item_List',
                                options=[
                                    {'label': 'Online transactions', 'value': 'Online'},
                                    {'label': 'Offline transactions', 'value': 'Offline'},
                                    {'label': 'Donations from funding agencies', 'value': 'Donations '}
                                ],
                                value=['Online', 'Offline', 'Donations '],
                                labelStyle={'display': 'inline-block','color':'white'},
                                
                        ),
                    ],
                    className='six columns',
                           style={'backgroundColor': colors['background']}
                ),
            ], className="row"
        ),
#-----------------------

                                dcc.Graph(id='dash_graph',figure=fig2
),
                                 
                                dcc.Graph(
        id='example-graph-2',
        figure=fig
    ),
                                    dcc.Graph(id='enrollment_age',
                           figure=go.Figure(
                               data=[go.Pie(labels=['Early childhood [months-8 years]', '9-13 years', '13-18 years'],
                                            values=['22344', '10642', '9390'],hole=.5,marker_colors= cafe_colors)],
                               layout=go.Layout(
                                   title='Enrollment age of children in NGOs',
                                   font_color='white',
                                   paper_bgcolor='rgba(0,0,0,0)',
            plot_bgcolor='rgba(0,0,0,0)'),
                               
                              
                           )),
                                      html.Div(children='VOLUNTEERS VS BENEFITIARIES DISTRIBUTION', style={
        'textAlign': 'center',
        'color': colors['text']
    }),
                                    
                             dcc.Graph(
        id='graph-2',
        figure=fig1
    )
                                
                                ])
                            

@app.callback(
    dash.dependencies.Output('dash_graph', 'figure'),
    [dash.dependencies.Input('Item_List', 'value')])
def update_graph(selector):
    data = []
    if 'Online' in selector:
        data.append({'x':[1,2,3,4,5], 'y':[4,6,3,8,1], 'type': 'bar', 'name':'Online'})
    if 'Offline' in selector:
        data.append({'x':[1,2,3,4,5], 'y':[9,3,1,9,4], 'type': 'bar', 'name':'Offline'})
    if 'Donations ' in selector:
        data.append({'x':[1,2,3,4,5], 'y':[4,6,3,8,1], 'type': 'bar', 'name':'Donations '})
    figure = {
        
        'data': data,
        'layout': {
              'paper_bgcolor':'rgba(0,0,0,0)',
              'plot_bgcolor':'rgba(0,0,0,0)',
            'title': 'Graph depicting different types of fundings for different branches',
            'xaxis' : dict(
                title='Branches   1-VB Community , 2-St.Pathricks trust , 3-Jonathans foundation , 4-Dalits Foundation , 5-The Christian trust',
                titlefont=dict(
                family='Calibri, monospace',
                size=20,
                color='white',
            )),
            'yaxis' : dict(
                title='Types of donations',
                titlefont=dict(
                family='Garamond, monospace',
                size=20,
                color='#111111',
                backgroundColor='#F9FF33'
            ))
        }
    }
    return figure

#Code to run the application
if __name__ == '__main__':
    app.run_server(debug = True)